# Executar

Para executar os Exercícos nas pasta raís execute:

``` $ make release SRC=nomearquivo```

``` $ make run SRC=nomearquivo```

nomearquivo sem o ".c" (exemplo: exer01)

---

Para executar os Exercícos dentro de pastas "sepradas", abra o terminal dentro da pasta e execute:

``` $ make release```

``` $ make run```